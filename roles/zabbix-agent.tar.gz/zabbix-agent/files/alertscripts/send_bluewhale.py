#!/usr/bin/python
# -*- coding: utf-8 -*-
import sys
reload(sys)
sys.setdefaultencoding('utf-8')

import json
#import sys
import urllib,urllib2
import ssl
from os import system

#send wechart
content=sys.argv[1]  #many user: 'zhangsan|wangwu'
json_data = json.dumps(content)
url = 'https://paas.addpchina.com/o/alertcenter/alert/event_source/zabbix/'
request = urllib2.Request(url, json_data)
request.add_header('Content-Type','application/json')
response = urllib2.urlopen(request, context=ssl._create_unverified_context())
print(response.read().decode('utf-8'))
