#!/usr/bin/python
# -*- coding: utf-8 -*-
import json
import os
import sys
import urllib2
import csv
import codecs
import time
import ssl

reload(sys)
sys.setdefaultencoding('utf-8')

BLUEWHALE_ALERT_URL = 'https://paas.addpchina.com/o/alertcenter/alert/event_source/zabbix/'
SMS_ALERT_URL = ""
LOCAL_ALERT_FILE = "/var/log/zabbix/alart_recode.csv"
CSV_HEADER = ["now_time", "instance_id", "os_ip", "bk_obj_id", "status", "severity", "first_time",
              "latest_data", "description","alert_result","alert_resp_msg"]

def alert_to_bluewhale(json_data):
    ret_dict = {"success": False, "resp_msg": ""}
    try:
        request = urllib2.Request(BLUEWHALE_ALERT_URL, json_data,
                                  headers={'Content-Type': 'application/json'})
        response = urllib2.urlopen(request, context=ssl._create_unverified_context())
        resp_str = response.read().decode('utf-8')
        ret_dict["resp_msg"] = resp_str
        ret_dict["success"] = True
    except Exception as err:
        ret_dict["resp_msg"] = err
        ret_dict["success"] = False

    return ret_dict


def alert_to_sms(json_data):
    return False


def alert_to_local(json_data, append_msg, bw_ret):
    alert_json = json.loads(json_data, strict=False)
    if type(alert_json) != dict:
        alert_json = json.loads(alert_json, strict=False)

    alert_json["now_time"] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())

    if append_msg != "":
        alert_json["description"] = alert_json["description"] + append_msg

    alert_json["alert_result"]=bw_ret["success"]
    alert_json["alert_resp_msg"]=bw_ret["resp_msg"]

    path = os.path.dirname(LOCAL_ALERT_FILE)
    if not os.path.exists(path):
        os.makedirs(path)
    with open(LOCAL_ALERT_FILE, mode="ab") as f:
        # f.write(codecs.BOM_UTF8.decode())
        f_csv = csv.DictWriter(f, CSV_HEADER)
        f_csv.writerow(alert_json)

    if bw_ret["success"]:
        return True
    else:
        print bw_ret["resp_msg"]
        return False


# 转换description和latest_data中出现的双引号
def conver_spe_chart(input_msg):
    spec_chart_list=["\"description\": \"","\"latest_data\": \""]
    end_chart="\",\r\n"

    for spec_chart in spec_chart_list:
        a_index=input_msg.find(spec_chart)
        if a_index != -1:
            a_cut_prefix=input_msg[a_index+len(spec_chart):]
            a_cut_all=a_cut_prefix[:a_cut_prefix.find(end_chart)]
            a_new=a_cut_all.replace("\"", "\\\"")
            input_msg=input_msg.replace(a_cut_all,a_new)

    return input_msg

content = sys.argv[1]
# 有些not support信息会在内容前加note信息，这里把内容截取出来
ind = content.find("{")
append_msg = content[0:ind]
content = conver_spe_chart(content[ind:])

json_data = json.dumps(content)
json_data = json_data.replace("\\\\r", "").replace("\\\\n", "")
bw_ret = alert_to_bluewhale(json_data)
if alert_to_local(json_data, append_msg, bw_ret):
    exit(0)
else:
    exit(1)
