#!/bin/bash

#原始zabbix参数
to=$1
title=$2
content=$3

# {HOST.HOST1}|{HOST.NAME1}|{HOST.CONN1}|{TRIGGER.SEVERITY}|{INVENTORY.TYPE1}|{TRIGGER.STATUS}|{EVENT.DATE} {EVENT.TIME}|{ITEM.VALUE1}|{TRIGGER.NAME}


# echo $content >> /tmp/addp_alert.txt

#拆分参数
hostName=`(echo $content | cut -d '|' -f1)`
hostVisibleName=`(echo $content | cut -d '|' -f2)`
hostConn=`(echo $content | cut -d '|' -f3)`
severity=`(echo $content | cut -d '|' -f4)`
inventoryType=`(echo $content | cut -d '|' -f5)`
triggerStatus=`(echo $content | cut -d '|' -f6)`
eventDatetime=`(echo $content | cut -d '|' -f7)`
itemVal1=`(echo $content | cut -d '|' -f8)`
triggerName=`(echo $content | cut -d '|' -f9)`


# 组织数据

#特殊字符转移
hostName=`(echo $hostName | sed 's/"/\\\\"/g')`
hostVisibleName=`(echo $hostVisibleName | sed 's/"/\\\\"/g')`
title=`(echo $title | sed 's/"/\\\\"/g')`
itemVal1=`(echo $itemVal1 | sed 's/"/\\\\"/g')`
triggerName=`(echo $triggerName | sed 's/"/\\\\"/g')`
inventoryType=`(echo $inventoryType | sed 's/"/\\\\"/g')`

jsondata="{\
\"instance_id\":\""${hostName}"\",\
\"bk_obj_id\":\""${inventoryType}"\",\
\"os_ip\":\""${hostConn}"\",\
\"severity\":\""${severity}"\",\
\"status\":\""${triggerStatus}"\",\
\"latest_data\":\""${itemVal1}"\",\
\"first_time\":\""${eventDatetime}"\",\
\"description\":\""${triggerName}"\"\
}"

# echo ${jsondata} >> /tmp/addp_alert.txt

curl -v -L -X POST --header 'Content-Type: application/json' --header 'Accept: application/json' -d "${jsondata}" "http://10.127.46.29:8082/c_ac/zabbix"
#curl -v -L -X POST --header 'Content-Type: application/json' --header 'Accept: application/json' -d "${jsondata}" "http://paas.addpchina.com/t/alertcenter/alert/event_source/zabbix"


