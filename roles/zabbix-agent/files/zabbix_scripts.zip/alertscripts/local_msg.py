#!/usr/bin/python
# -*- coding: utf-8 -*-
import json
import os
import sys
import urllib2
import csv
import codecs
import time

reload(sys)
sys.setdefaultencoding('utf-8')

LOCAL_ALERT_FILE = "/var/log/zabbix/local_recode.csv"
CSV_HEADER = ["now_time", "instance_id", "os_ip", "bk_obj_id", "status", "severity", "first_time",
              "latest_data", "description"]


def alert_to_local(json_data, append_msg):
    alert_json = json.loads(json_data, strict=False)
    if type(alert_json) != dict:
        alert_json = json.loads(alert_json, strict=False)

    # 如果os_ip 和 instance_id 都是 unknow 则表示信息无效，不予记录
    instance_id = alert_json["instance_id"]
    os_ip = alert_json["os_ip"]
    if instance_id.find("UNKNOWN") != -1 and os_ip.find("UNKNOWN") != -1:
        return

    alert_json["now_time"] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())

    if append_msg != "":
        alert_json["description"] = alert_json["description"] + append_msg

    path = os.path.dirname(LOCAL_ALERT_FILE)
    if not os.path.exists(path):
        os.makedirs(path)
    with open(LOCAL_ALERT_FILE, mode="ab") as f:
        # f.write(codecs.BOM_UTF8.decode())
        f_csv = csv.DictWriter(f, CSV_HEADER)
        f_csv.writerow(alert_json)


# 转换description和latest_data中出现的双引号
def conver_spe_chart(input_msg):
    spec_chart_list=["\"description\": \"","\"latest_data\": \""]
    end_chart="\",\r\n"

    for spec_chart in spec_chart_list:
        a_index=input_msg.find(spec_chart)
        if a_index != -1:
            a_cut_prefix=input_msg[a_index+len(spec_chart):]
            a_cut_all=a_cut_prefix[:a_cut_prefix.find(end_chart)]
            a_new=a_cut_all.replace("\"", "\\\"")
            input_msg=input_msg.replace(a_cut_all,a_new)

    return input_msg


content = sys.argv[1]
# 有些not support信息会在内容前加note信息，这里把内容截取出来
ind = content.find("{")
append_msg = content[0:ind]
content = conver_spe_chart(content[ind:])

json_data = json.dumps(content)
json_data = json_data.replace("\\\\r", "").replace("\\\\n", "")
alert_to_local(json_data, append_msg)
